﻿// Game example
//
// Requires Visual Studio 2012 and .NET 4.5

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SmileyKillersControls;

namespace SmileyShooter
{
    public partial class Form1 : Form
    {
        // Form's constructor
        public Form1()
        {
            // let's initialize all the components on the form
            InitializeComponent();

            // we need to add references to all the smiley control instances to the list in the game kernel
            //
            // if we want to do it, we can use the following foreach statement, which goes through all the controls on
            // the panel2 and if it finds a SmileyKiller control, it adds it to the list in the Game class
            // ADVANTAGE: you don't have to remember instance names and all controls are added even if you remove or add them.
            foreach (Control cont in panel2.Controls) {
                if (cont.GetType().Name == "SmileyKiller")
                {
                    // foreach uses the Control data type (superclass of all the visual controls) so it is necessary
                    // to directly re-type all the found controls to SmileyKiller type so they can be added to the list
                    Game.smileys.Add((SmileyKiller)cont);
                }
            }

            // we can also do the same manually:
            // ADVANTAGE: I don't have to know how to use foreach :)
            // DISADVANTAGE: I have to know names of all the SmileyKiller instances and when I do changes (add/remove) I have
            // to reflect that in this code

      /*    Game.smileys.Add(smileyKiller1);
            Game.smileys.Add(smileyKiller2);
            Game.smileys.Add(smileyKiller3);
            Game.smileys.Add(smileyKiller4);
            Game.smileys.Add(smileyKiller5);
            Game.smileys.Add(smileyKiller6);
            Game.smileys.Add(smileyKiller7);
            Game.smileys.Add(smileyKiller8);
            Game.smileys.Add(smileyKiller9);
            Game.smileys.Add(smileyKiller10);
            Game.smileys.Add(smileyKiller11);
            Game.smileys.Add(smileyKiller12);*/

            // we cycle through all the smiley controls in the Game's list and add right methods to each of the delegates
            for (int i = 0; i < Game.smileys.Count(); i++)
            {
                // Game.ScoreEmpty will be called everytime we click on smiley control which is empty
                Game.smileys[i].ClickEmpty = new ProcessClick(Game.ScoreEmpty);
                // Game.ScoreKillShot will be called everytime we click on smiley control which contains bandit (ie. when we hit him)
                Game.smileys[i].ClickKiller = new ProcessClick(Game.ScoreKillShot);
            }

            // and also we need to connect the Game kernel with the method of the form which updates the score
            Game.UpdateScore = new UpdateScoreMethod(UpdateScore);
        }

        // method used for updating the score on the form
        public void UpdateScore(string score)
        {
            label1.Text = score;
        }

        // when we click anywhere in the form and not on the bandit, we miss - for this we have to call the ScoreEmpty() method
        private void Panel2_Click(object sender, EventArgs e)
        {
            Game.ScoreEmpty();
        }

        // when I press Start button, I restart the game - for that I need to call Reset() method, start the time counter and
        // disable this button so I cannot start the game again while it is running
        private void button1_Click(object sender, EventArgs e)
        {
            Game.Reset();
            timer1.Enabled = true;
            button1.Enabled = false;
        }

        // this method is executed everytime the timer1 ticks
        private void timer1_Tick(object sender, EventArgs e)
        {
            // game time is decreased by 5
            Game.Time -= 5;
            // show the time on the progress bar
            progressBar1.Value = Game.Time;
            // if the time runs out
            if (Game.Time <= 0)
            {
                // stop the game
                Game.EndGame();
                // update hi score
                label4.Text = Game.HiScore.ToString();
                // enable Start button
                button1.Enabled = true;
                // stop game time counter
                timer1.Enabled = false;
                // show Game Over message
                MessageBox.Show("Game Over!");
            }

        }
    }
}
