﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SmileyKillersControls;

namespace SmileyShooter
{
    // To enable communication between the game kernel (Game class) and the UI we need to define a delegate
    // type that can be used to initiate score update in the UI.
    public delegate void UpdateScoreMethod(string score);

    // Kernel of the whole game, the Game class. It is static because we only need it in one copy and
    // do not need to make any instances of it.
    public static class Game
    {
        // Properties definitions:
        public static int Score { get; set; }    // integer - score counter
        public static int HiScore { get; set; }  // integer - hi score since the game was run
        public static int Time { get; set; }     // integer - how much time do we have till the end of the game
        public static bool Status { get; set; }  // boolean - game status - true = game is running, false = game is stopped
        public static UpdateScoreMethod UpdateScore { get; set; }  // delegate instance used to connect the Game class with UI
        public static List<SmileyKiller> smileys = new List<SmileyKiller>(); // List of all the instances of the SmileyKiller control

        // private variable containing an index of the active killer, -1 if the game was not run
        private static int _activeKiller = -1;

        // constructor
        static Game()
        {
            Score = 0;
            HiScore = 0;
            Status = false;
            UpdateScore = null;
        }

        // method for restarting the game - active score is set to 0, time counter to full time, status to running game and
        // also creater the first bandit
        public static void Reset() 
        {
            Score = 0;
            Time = 100;
            Status = true;
            CreateKiller();
        }

        // method which is executed using delegate from the SmileyKiller control whenever we click on it and it is empty
        public static void ScoreEmpty()
        {
            // executed only if Status is true
            if (Status)
            {
                // remove 10 points from the actual score for missing the shot
                Score -= 10;
                // if the Game class is connected to UI using delegate (delegate instance is not null) then execute the delegate
                if (UpdateScore != null) UpdateScore(Score.ToString());
            }
        }

        // method executed from the SmileyKiller control using a delegate whenever we hit the bandit
        //
        // BEWARE: Because we need to "slow down" the execution of the method so the image of the Smiley being hit is
        // shown for some time, we define this method as asynchronous (it is executed separately from the main program) 
        // and slow it down using the await Task.Delay() call, which stops the method until the Delay() method is finished.
        // Unlike Thread.Sleep() this solution doesn't freeze the whole application and it runs simultaneously.
        // Because of that we need to use the Game.Status property, otherwise it may happen that while this method is
        // still running, game time runs out in the main program and the game gets into a erroneous state.
        public static async void ScoreKillShot()
        {
            Score += 50;
            if (UpdateScore != null) UpdateScore(Score.ToString());
            await Task.Delay(200);
            smileys[_activeKiller].Status = SmileyState.Empty;
            await Task.Delay(200);
            CreateKiller();
        }

        // method for creating a bandit
        public static void CreateKiller()
        {
            // if Status is true then the game is running and I can create bandit - we have to check this because of the
            // asynchronous method ScoreKillShot
            if (Status)
            {
                // create random number generater
                Random r = new Random();

                // generate number from an interval of <0, number of smileys)
                _activeKiller = r.Next(smileys.Count());
                // smiley with this index is set to be the bandit
                smileys[_activeKiller].Status = SmileyState.Killer;
            }

        }

        // this method is used to end the game correctly
        public static void EndGame()
        {
            // set Status to false, game is stopped
            Status = false;
            // active smiley is set to empty (no smiley is shown)
            smileys[_activeKiller].Status = SmileyState.Empty;
            // if our current score is higher than hi score then update the hi score
            if (Game.Score > Game.HiScore) Game.HiScore = Game.Score;
        }

    }
}
