﻿namespace SmileyShooter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel2 = new SmileyShooter.PanelDoubleBuffer();
            this.smileyKiller12 = new SmileyKillersControls.SmileyKiller();
            this.smileyKiller7 = new SmileyKillersControls.SmileyKiller();
            this.smileyKiller11 = new SmileyKillersControls.SmileyKiller();
            this.smileyKiller1 = new SmileyKillersControls.SmileyKiller();
            this.smileyKiller10 = new SmileyKillersControls.SmileyKiller();
            this.smileyKiller2 = new SmileyKillersControls.SmileyKiller();
            this.smileyKiller9 = new SmileyKillersControls.SmileyKiller();
            this.smileyKiller3 = new SmileyKillersControls.SmileyKiller();
            this.smileyKiller8 = new SmileyKillersControls.SmileyKiller();
            this.smileyKiller4 = new SmileyKillersControls.SmileyKiller();
            this.smileyKiller5 = new SmileyKillersControls.SmileyKiller();
            this.smileyKiller6 = new SmileyKillersControls.SmileyKiller();
            this.panel1 = new SmileyShooter.PanelDoubleBuffer();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // panel2
            // 
            this.panel2.BackgroundImage = global::SmileyShooter.Properties.Resources.saloon;
            this.panel2.Controls.Add(this.smileyKiller12);
            this.panel2.Controls.Add(this.smileyKiller7);
            this.panel2.Controls.Add(this.smileyKiller11);
            this.panel2.Controls.Add(this.smileyKiller1);
            this.panel2.Controls.Add(this.smileyKiller10);
            this.panel2.Controls.Add(this.smileyKiller2);
            this.panel2.Controls.Add(this.smileyKiller9);
            this.panel2.Controls.Add(this.smileyKiller3);
            this.panel2.Controls.Add(this.smileyKiller8);
            this.panel2.Controls.Add(this.smileyKiller4);
            this.panel2.Controls.Add(this.smileyKiller5);
            this.panel2.Controls.Add(this.smileyKiller6);
            this.panel2.Cursor = System.Windows.Forms.Cursors.NoMove2D;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(800, 533);
            this.panel2.TabIndex = 14;
            this.panel2.Click += new System.EventHandler(this.Panel2_Click);
            // 
            // smileyKiller12
            // 
            this.smileyKiller12.BackColor = System.Drawing.Color.Transparent;
            this.smileyKiller12.ClickEmpty = null;
            this.smileyKiller12.ClickKiller = null;
            this.smileyKiller12.Location = new System.Drawing.Point(371, 145);
            this.smileyKiller12.Name = "smileyKiller12";
            this.smileyKiller12.Size = new System.Drawing.Size(46, 46);
            this.smileyKiller12.Status = SmileyKillersControls.SmileyState.Empty;
            this.smileyKiller12.TabIndex = 26;
            this.smileyKiller12.Text = "smileyKiller12";
            // 
            // smileyKiller7
            // 
            this.smileyKiller7.BackColor = System.Drawing.Color.Transparent;
            this.smileyKiller7.ClickEmpty = null;
            this.smileyKiller7.ClickKiller = null;
            this.smileyKiller7.Location = new System.Drawing.Point(188, 68);
            this.smileyKiller7.Name = "smileyKiller7";
            this.smileyKiller7.Size = new System.Drawing.Size(46, 46);
            this.smileyKiller7.Status = SmileyKillersControls.SmileyState.Empty;
            this.smileyKiller7.TabIndex = 21;
            this.smileyKiller7.Text = "smileyKiller7";
            // 
            // smileyKiller11
            // 
            this.smileyKiller11.BackColor = System.Drawing.Color.Transparent;
            this.smileyKiller11.ClickEmpty = null;
            this.smileyKiller11.ClickKiller = null;
            this.smileyKiller11.Location = new System.Drawing.Point(156, 332);
            this.smileyKiller11.Name = "smileyKiller11";
            this.smileyKiller11.Size = new System.Drawing.Size(46, 46);
            this.smileyKiller11.Status = SmileyKillersControls.SmileyState.Empty;
            this.smileyKiller11.TabIndex = 25;
            this.smileyKiller11.Text = "smileyKiller11";
            // 
            // smileyKiller1
            // 
            this.smileyKiller1.BackColor = System.Drawing.Color.Transparent;
            this.smileyKiller1.ClickEmpty = null;
            this.smileyKiller1.ClickKiller = null;
            this.smileyKiller1.Location = new System.Drawing.Point(469, 121);
            this.smileyKiller1.Name = "smileyKiller1";
            this.smileyKiller1.Size = new System.Drawing.Size(50, 50);
            this.smileyKiller1.Status = SmileyKillersControls.SmileyState.Empty;
            this.smileyKiller1.TabIndex = 15;
            this.smileyKiller1.Text = "smileyKiller1";
            // 
            // smileyKiller10
            // 
            this.smileyKiller10.BackColor = System.Drawing.Color.Transparent;
            this.smileyKiller10.ClickEmpty = null;
            this.smileyKiller10.ClickKiller = null;
            this.smileyKiller10.Location = new System.Drawing.Point(371, 246);
            this.smileyKiller10.Name = "smileyKiller10";
            this.smileyKiller10.Size = new System.Drawing.Size(46, 46);
            this.smileyKiller10.Status = SmileyKillersControls.SmileyState.Empty;
            this.smileyKiller10.TabIndex = 24;
            this.smileyKiller10.Text = "smileyKiller10";
            // 
            // smileyKiller2
            // 
            this.smileyKiller2.BackColor = System.Drawing.Color.Transparent;
            this.smileyKiller2.ClickEmpty = null;
            this.smileyKiller2.ClickKiller = null;
            this.smileyKiller2.Location = new System.Drawing.Point(90, 125);
            this.smileyKiller2.Name = "smileyKiller2";
            this.smileyKiller2.Size = new System.Drawing.Size(46, 46);
            this.smileyKiller2.Status = SmileyKillersControls.SmileyState.Empty;
            this.smileyKiller2.TabIndex = 16;
            this.smileyKiller2.Text = "smileyKiller2";
            // 
            // smileyKiller9
            // 
            this.smileyKiller9.BackColor = System.Drawing.Color.Transparent;
            this.smileyKiller9.ClickEmpty = null;
            this.smileyKiller9.ClickKiller = null;
            this.smileyKiller9.Location = new System.Drawing.Point(469, 53);
            this.smileyKiller9.Name = "smileyKiller9";
            this.smileyKiller9.Size = new System.Drawing.Size(46, 46);
            this.smileyKiller9.Status = SmileyKillersControls.SmileyState.Empty;
            this.smileyKiller9.TabIndex = 23;
            this.smileyKiller9.Text = "smileyKiller9";
            // 
            // smileyKiller3
            // 
            this.smileyKiller3.BackColor = System.Drawing.Color.Transparent;
            this.smileyKiller3.ClickEmpty = null;
            this.smileyKiller3.ClickKiller = null;
            this.smileyKiller3.Location = new System.Drawing.Point(255, 226);
            this.smileyKiller3.Name = "smileyKiller3";
            this.smileyKiller3.Size = new System.Drawing.Size(46, 46);
            this.smileyKiller3.Status = SmileyKillersControls.SmileyState.Empty;
            this.smileyKiller3.TabIndex = 17;
            this.smileyKiller3.Text = "smileyKiller3";
            // 
            // smileyKiller8
            // 
            this.smileyKiller8.BackColor = System.Drawing.Color.Transparent;
            this.smileyKiller8.ClickEmpty = null;
            this.smileyKiller8.ClickKiller = null;
            this.smileyKiller8.Location = new System.Drawing.Point(720, 272);
            this.smileyKiller8.Name = "smileyKiller8";
            this.smileyKiller8.Size = new System.Drawing.Size(46, 46);
            this.smileyKiller8.Status = SmileyKillersControls.SmileyState.Empty;
            this.smileyKiller8.TabIndex = 22;
            this.smileyKiller8.Text = "smileyKiller8";
            // 
            // smileyKiller4
            // 
            this.smileyKiller4.BackColor = System.Drawing.Color.Transparent;
            this.smileyKiller4.ClickEmpty = null;
            this.smileyKiller4.ClickKiller = null;
            this.smileyKiller4.Location = new System.Drawing.Point(530, 256);
            this.smileyKiller4.Name = "smileyKiller4";
            this.smileyKiller4.Size = new System.Drawing.Size(46, 46);
            this.smileyKiller4.Status = SmileyKillersControls.SmileyState.Empty;
            this.smileyKiller4.TabIndex = 18;
            this.smileyKiller4.Text = "smileyKiller4";
            // 
            // smileyKiller5
            // 
            this.smileyKiller5.BackColor = System.Drawing.Color.Transparent;
            this.smileyKiller5.ClickEmpty = null;
            this.smileyKiller5.ClickKiller = null;
            this.smileyKiller5.Location = new System.Drawing.Point(597, 121);
            this.smileyKiller5.Name = "smileyKiller5";
            this.smileyKiller5.Size = new System.Drawing.Size(46, 46);
            this.smileyKiller5.Status = SmileyKillersControls.SmileyState.Empty;
            this.smileyKiller5.TabIndex = 19;
            this.smileyKiller5.Text = "smileyKiller5";
            // 
            // smileyKiller6
            // 
            this.smileyKiller6.BackColor = System.Drawing.Color.Transparent;
            this.smileyKiller6.ClickEmpty = null;
            this.smileyKiller6.ClickKiller = null;
            this.smileyKiller6.Location = new System.Drawing.Point(12, 256);
            this.smileyKiller6.Name = "smileyKiller6";
            this.smileyKiller6.Size = new System.Drawing.Size(46, 46);
            this.smileyKiller6.Status = SmileyKillersControls.SmileyState.Empty;
            this.smileyKiller6.TabIndex = 20;
            this.smileyKiller6.Text = "smileyKiller6";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.progressBar1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(799, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(182, 533);
            this.panel1.TabIndex = 13;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.ForeColor = System.Drawing.Color.Green;
            this.label4.Location = new System.Drawing.Point(73, 59);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(24, 25);
            this.label4.TabIndex = 9;
            this.label4.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(18, 68);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Hi Score:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Score:";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(52, 165);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 6;
            this.button1.Text = "START";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(12, 108);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(158, 31);
            this.progressBar1.TabIndex = 5;
            this.progressBar1.Value = 100;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(73, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(24, 25);
            this.label1.TabIndex = 4;
            this.label1.Text = "0";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(981, 533);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.DoubleBuffered = true;
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Button button1;
        private SmileyShooter.PanelDoubleBuffer panel2;
        private SmileyKillersControls.SmileyKiller smileyKiller12;
        private SmileyKillersControls.SmileyKiller smileyKiller7;
        private SmileyKillersControls.SmileyKiller smileyKiller11;
        private SmileyKillersControls.SmileyKiller smileyKiller1;
        private SmileyKillersControls.SmileyKiller smileyKiller10;
        private SmileyKillersControls.SmileyKiller smileyKiller2;
        private SmileyKillersControls.SmileyKiller smileyKiller9;
        private SmileyKillersControls.SmileyKiller smileyKiller3;
        private SmileyKillersControls.SmileyKiller smileyKiller8;
        private SmileyKillersControls.SmileyKiller smileyKiller4;
        private SmileyKillersControls.SmileyKiller smileyKiller5;
        private SmileyKillersControls.SmileyKiller smileyKiller6;
        private System.Windows.Forms.Timer timer1;
        private PanelDoubleBuffer panel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
    }
}

