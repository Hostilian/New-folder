﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SmileyShooter
{
    // This class extends the original Panel container class. As we need the panel content to be drawn flicker-less,
    // we have to use double buffering and the only way to enable it is in the Panel's constructor.
    // This new component works in the same way as the original Panel and can be found in the Toolbox together with other
    // visual components.
    public class PanelDoubleBuffer : Panel
    {
        public PanelDoubleBuffer()
            : base()
        {
            this.SetStyle(ControlStyles.DoubleBuffer, true);
            this.SetStyle(ControlStyles.AllPaintingInWmPaint, true);
            this.SetStyle(ControlStyles.UserPaint, true);
        }
    }
}
