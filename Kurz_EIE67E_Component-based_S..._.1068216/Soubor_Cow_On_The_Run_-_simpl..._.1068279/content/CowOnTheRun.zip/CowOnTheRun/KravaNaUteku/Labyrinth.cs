﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Timers;

namespace CowOnTheRun
{
    // definition of the delegate used to refresh the panel with labyrinth
    public delegate void PanelRefresh();

    // structure containing some position inside the labyrinth
    public struct Position
    {
        public int x;
        public int y;
    }

    // class representing the labyrinth - takes care off its initialization, cow's movements, 
    // controls refreshes of the panel etc.
    public static class Labyrinth
    {
        // definition of the basic positions inside the labyrinth:
        // starting point of the cow, the exit and the current position of the cow
        public static Position start = new Position();
        public static Position exit = new Position();
        public static Position position = new Position();

        // the labyrinth is represented using a 2 dimensional array of integers,
        // where 0 means clear passage and 1 means wall
        static int[,] labyrinth = new int[35, 25];

        // creating a concrete empty instance of the refresh delegate;
        // it will be used inside the class's methods as a call for refreshing the panel
        public static PanelRefresh refresh = null;

        // constructor - to allow creating labyrinth not only from there but also from another methods,
        // it only contains a call to labyrinth Initialize method
        static Labyrinth()
        {
            Initialize();
        }

        // this method initializes the labyrinth
        public static void Initialize()
        {

            // first we have to create an instance of the random number generator
            Random random = new Random();
            // now we generate a number between 1 and 12
            int rndNumber = random.Next(1, 13);

            // now we load a bitmap with this number from the resources repository
            Bitmap labyrinthBmp = (Bitmap)global::CowOnTheRun.Properties.Resources.ResourceManager.GetObject("bludiste" + rndNumber);

            // and call a method that converts the image to our labyrinth array representation
            GenerateLabyrinth(labyrinthBmp);
        }

        // this method takes a memory bitmap as a parameter, traverses the bitmap pixel by pixel
        // and based on the pixel's color decides whether it is a free passage, a wall, start or exit
        private static void GenerateLabyrinth(Bitmap labyrinthBmp)
        {
            for (int y = 0; y < 25; y++)
            {
                for (int x = 0; x < 35; x++)
                {
                    if (labyrinthBmp.GetPixel(x, y).Name == "ff000000")
                        labyrinth[x, y] = 1;
                    else
                        labyrinth[x, y] = 0;
                    if (labyrinthBmp.GetPixel(x, y).Name == "ffff0000")
                    {
                        start.x = x;
                        start.y = y;
                    }
                    if (labyrinthBmp.GetPixel(x, y).Name == "ff4cff00")
                    {
                        exit.x = x;
                        exit.y = y;
                    }

                }
            }

            position = start;
        }

        // returns true if there's a wall on given coordinates
        public static bool IsWall(int x, int y)
        {
            if (labyrinth[x, y] == 1) return true;
            else 
                return false;
        }

        // creates a new labyrinth and ask for panel refresh so it can be drawn
        public static void NewLabyrinth()
        {
            Initialize();
            if (refresh != null) refresh();
        }

        // method for cow's moving left - only this method is commented in more detail 
        // as the other movement methods are similar, just going in other directions
        public static bool GoLeft()
        {
            if (position.x > 0)  // test if we're not getting outside the labyrinth's borders
            {
                if (labyrinth[position.x - 1, position.y] == 0)  // if the position we'd like to go to is free, then:
                {
                    position.x--;                             // change the current position's x coordinate to this position
                    if (refresh != null) refresh();           // ask the panel to redraw
                }
                if (position.x == exit.x && position.y == exit.y)  // if the current position is the same as the exit
                    return true;                                   // return true because we are at the end of the labyrinth
            }
            return false;                                   // otherwise return false because we haven't find the exit yet
        }

        // cow moving right
        public static bool GoRight()
        {
            if (position.x < 34)
            {
                if (labyrinth[position.x + 1, position.y] == 0)
                {
                    position.x++;
                    if (refresh != null) refresh();
                }
                if (position.x == exit.x && position.y == exit.y)
                    return true;
            }
            return false;
        }

        // cow moving up
        public static bool GoUp()
        {
            if (position.y > 0)
            {
                if (labyrinth[position.x, position.y - 1] == 0)
                {
                    position.y--;
                    if (refresh != null) refresh();
                }
                if (position.x == exit.x && position.y == exit.y)
                    return true;
            }
            return false;
        }

        // cow moving down
        public static bool GoDown()
        {
            if (position.y < 24)
            {
                if (labyrinth[position.x, position.y + 1] == 0)
                {
                    position.y++;
                    if (refresh != null) refresh();
                }
                if (position.x == exit.x && position.y == exit.y)
                    return true;
            }
            return false;
        }


    }
}
