﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CowOnTheRun
{
    // This class is derived from the original Panel control. In our game we use Panel as the control where the whole
    // labyrinth is drawn on. To make the graphics flicker-free we have to use the double buffering. This can however 
    // only be turned on in the control's contructor. To make it work we have to create a derived class, like this one,
    // and turn the double buffering on in the constructor using the three statements written in the constructor bellow.
    // This deriver control is then available in the Toolbox and it can be used just as the normal Panel control.

    public class PanelDoubleBuffer : Panel
    {
        public PanelDoubleBuffer()
            : base()
        {
            this.SetStyle(ControlStyles.DoubleBuffer, true);
            this.SetStyle(ControlStyles.AllPaintingInWmPaint, true);
            this.SetStyle(ControlStyles.UserPaint, true);
        }
    }
}
