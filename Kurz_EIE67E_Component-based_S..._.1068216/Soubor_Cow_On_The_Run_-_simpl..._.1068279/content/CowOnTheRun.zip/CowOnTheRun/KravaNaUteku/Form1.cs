﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CowOnTheRun
{
    // the main form of our game
    public partial class Form1 : Form
    {
        // here we download particular sprites from the resource repository
        Image wall = global::CowOnTheRun.Properties.Resources.dlazdice;
        Image cow = global::CowOnTheRun.Properties.Resources.krava;
        Image exit = global::CowOnTheRun.Properties.Resources.vychod;

        // form's constructor
        public Form1()
        {
            InitializeComponent();
            // here we assign the form's RedrawLabyrinth method to Labyrinth's refresh delegate,
            // so each time the refresh is called inside the Labyrinth class, the method RedrawLabyrinth
            // method is called and processed.
            Labyrinth.refresh += new PanelRefresh(RedrawLabyrinth);
        }

        // event handler of the form's onPaint event;
        // it's used to draw the labyrinth on our derived Panel control's Graphics object
        private void panelDoubleBuffer1_Paint(object sender, PaintEventArgs e)
        {
            // we take the panel's Graphics object from the PaintEventArgs
            Graphics g = e.Graphics;

            // here we walk through the whole labyrinth grid
            for (int y = 0; y < 25; y++)  // rows
            {
                for (int x = 0; x < 35; x++)  // columns
                {
                    // if there's a wall on a given coordinates we'll draw it
                    if (Labyrinth.IsWall(x,y)) g.DrawImage(wall, x * 25, y * 25);
                }
            }

            // then we draw cow on it's coordinates
            g.DrawImage(cow, Labyrinth.position.x * 25, Labyrinth.position.y * 25);
            // and finally we draw the exit sign
            g.DrawImage(exit, Labyrinth.exit.x * 25, Labyrinth.exit.y * 25);
        }

        // this method is called by the Labyrinth.refresh delegate;
        // it only tells our Panel to redraw itself
        public void RedrawLabyrinth()
        {
            panelDoubleBuffer1.Invalidate();
        }

        // event handler of the form's onKeyDown event;
        // it processes the key presses
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            // we read the key information from the KeyEventArgs
            Keys button = e.KeyData;
            
            // and call the method that moves the cow in the direction based on the key pressed;
            // this method returns boolean result, based on whether we reached the exit or not
            bool result = ProcessMovement(button);

            // if the cow reached the exit then:
            if (result)
            {
                Moo();  // play the MOOOOO sound
                MessageBox.Show("No milk today, the cow has run away...");  // show the message
                Labyrinth.NewLabyrinth();  // and create a new labyrinth
            }

        }

        // play the moo sound stored in the resource repository
        private void Moo()
        {
            System.Media.SoundPlayer sound = new System.Media.SoundPlayer();
            sound.Stream = global::CowOnTheRun.Properties.Resources.buu;
            sound.Play();
        }

        // this method moves the cow based on the key that is pressed
        private static bool ProcessMovement(Keys button)
        {
            // this variables is used to store the movement result (have we reached the exit or not?)
            bool result = false;

            // move the cow in the right direction based on the key pressed
            switch (button)
            {
                case Keys.Up:
                    result = Labyrinth.GoUp();
                    break;
                case Keys.Down:
                    result = Labyrinth.GoDown();
                    break;
                case Keys.Left:
                    result = Labyrinth.GoLeft();
                    break;
                case Keys.Right:
                    result = Labyrinth.GoRight();
                    break;
            }
            // and return whether we reached the exit or not
            return result;
        }

    }
}
