﻿namespace CowOnTheRun
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelDoubleBuffer1 = new CowOnTheRun.PanelDoubleBuffer();
            this.SuspendLayout();
            // 
            // panelDoubleBuffer1
            // 
            this.panelDoubleBuffer1.BackColor = System.Drawing.Color.Black;
            this.panelDoubleBuffer1.Location = new System.Drawing.Point(0, 0);
            this.panelDoubleBuffer1.Name = "panelDoubleBuffer1";
            this.panelDoubleBuffer1.Size = new System.Drawing.Size(875, 625);
            this.panelDoubleBuffer1.TabIndex = 0;
            this.panelDoubleBuffer1.Paint += new System.Windows.Forms.PaintEventHandler(this.panelDoubleBuffer1_Paint);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(875, 625);
            this.Controls.Add(this.panelDoubleBuffer1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(885, 657);
            this.Name = "Form1";
            this.Text = "Kráva na útěku";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.ResumeLayout(false);

        }

        #endregion

        private PanelDoubleBuffer panelDoubleBuffer1;
    }
}

