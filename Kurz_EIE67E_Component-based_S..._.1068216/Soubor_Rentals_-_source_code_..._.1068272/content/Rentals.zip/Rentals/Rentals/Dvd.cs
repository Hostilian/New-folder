﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rentals
{
    public class Dvd : Disc
    {
        public Dvd(string title, string director, string genre, int price, bool restricted = false) : base(title, genre, price)
        {
            Director = director;
            Restricted = restricted;
        }

        public string Director {  get; set; }
        public bool Restricted { get; set; }


    }
}
