﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rentals
{
    public abstract class Disc
    {
        public string Title { get; set; }
        public string Genre { get; set; }
        public int Price { get; set; }

        public Disc(string title, string genre, int price)
        {
            Title = title;
            Genre = genre;
            Price = price;
        }
    }
}
