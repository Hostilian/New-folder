﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rentals
{
    public static class Database
    {
        public static BindingList<Customer> Customers { get; private set; } = [];
        public static BindingList<Disc> Stock { get; private set; } = [];

        static Database()
        {
            Customers.Add(new Customer("John", "Doe", "Prague", 1985));
            Customers.Add(new Customer("Peter", "Parker", "New York", 2005));
            Customers.Add(new Customer("Moe", "Sziszlak", "Springfield", 1975));
            Customers.Add(new Customer("Bart", "Simpson", "Springfield", 2014));

            Stock.Add(new CD("Black Album", "Metallica", "metal", 25));
            Stock.Add(new CD("Rosenrot", "Rammstein", "metal", 25));
            Stock.Add(new CD("Black Ice", "AC/DC", "rock", 25));
            Stock.Add(new CD("Blue Blood", "X Japan", "metal", 25));

            Stock.Add(new Dvd("Titanic", "James Cameron", "romantic", 30));
            Stock.Add(new Dvd("Interstellar", "Chris Nolan", "scifi", 30));
            Stock.Add(new Dvd("Home Alone", "Chris Columbus", "comedy", 30));
            Stock.Add(new Dvd("Texas chainsaw massacre", "Some Guy", "horror", 30, true));
        }
    }
}
