namespace Rentals
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            dgvCustomers.DataSource = Database.Customers;
            dgvStock.DataSource = Database.Stock;
        }

        private void btnRent_Click(object sender, EventArgs e)
        {
            Database.Customers.Add(new Customer("a", "b", "c", 1900));
        }
    }
}
