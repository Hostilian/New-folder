﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorNicer
{
    public static class Calc
    {
        public static double Add(double a, double b) { return a + b; }
        public static double Subtract(double a, double b) { return a - b; }
        public static double Multiply(double a, double b) { return a * b; }
        public static double Divide(double a, double b) { return a / b; }

        public static string Add(string a, string b)
        {
            return Add(double.Parse(a), double.Parse(b)).ToString();
        }

        public static string Subtract(string a, string b) 
        { 
            return Subtract(double.Parse(a),double.Parse(b)).ToString();
        }

        public static string Multiply(string a, string b)
        {
            return Multiply(double.Parse(a), double.Parse(b)).ToString();
        }

        public static string Divide(string a, string b)
        {
            return Divide(double.Parse(a), double.Parse(b)).ToString();
        }
    }
}
