﻿namespace CalculatorNicer
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnDivide = new Button();
            btnMultiply = new Button();
            btnSubtract = new Button();
            btnAdd = new Button();
            txtResult = new TextBox();
            txtB = new TextBox();
            txtA = new TextBox();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            SuspendLayout();
            // 
            // btnDivide
            // 
            btnDivide.Font = new Font("Segoe UI", 36F, FontStyle.Bold);
            btnDivide.Location = new Point(141, 276);
            btnDivide.Name = "btnDivide";
            btnDivide.Size = new Size(113, 107);
            btnDivide.TabIndex = 19;
            btnDivide.Text = "/";
            btnDivide.UseVisualStyleBackColor = true;
            btnDivide.Click += btnDivide_Click;
            // 
            // btnMultiply
            // 
            btnMultiply.Font = new Font("Segoe UI", 36F, FontStyle.Bold);
            btnMultiply.Location = new Point(22, 276);
            btnMultiply.Name = "btnMultiply";
            btnMultiply.Size = new Size(113, 107);
            btnMultiply.TabIndex = 18;
            btnMultiply.Text = "*";
            btnMultiply.UseVisualStyleBackColor = true;
            btnMultiply.Click += btnMultiply_Click;
            // 
            // btnSubtract
            // 
            btnSubtract.Font = new Font("Segoe UI", 36F, FontStyle.Bold);
            btnSubtract.Location = new Point(141, 163);
            btnSubtract.Name = "btnSubtract";
            btnSubtract.Size = new Size(113, 107);
            btnSubtract.TabIndex = 17;
            btnSubtract.Text = "-";
            btnSubtract.UseVisualStyleBackColor = true;
            btnSubtract.Click += btnSubtract_Click;
            // 
            // btnAdd
            // 
            btnAdd.Font = new Font("Segoe UI", 36F, FontStyle.Bold);
            btnAdd.Location = new Point(22, 163);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(113, 107);
            btnAdd.TabIndex = 16;
            btnAdd.Text = "+";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // txtResult
            // 
            txtResult.Location = new Point(119, 109);
            txtResult.Name = "txtResult";
            txtResult.Size = new Size(135, 23);
            txtResult.TabIndex = 15;
            // 
            // txtB
            // 
            txtB.Location = new Point(119, 55);
            txtB.Name = "txtB";
            txtB.Size = new Size(135, 23);
            txtB.TabIndex = 14;
            // 
            // txtA
            // 
            txtA.Location = new Point(119, 15);
            txtA.Name = "txtA";
            txtA.Size = new Size(135, 23);
            txtA.TabIndex = 13;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(22, 112);
            label3.Name = "label3";
            label3.Size = new Size(42, 15);
            label3.TabIndex = 12;
            label3.Text = "Result:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(22, 58);
            label2.Name = "label2";
            label2.Size = new Size(48, 15);
            label2.TabIndex = 11;
            label2.Text = "Value B:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(22, 18);
            label1.Name = "label1";
            label1.Size = new Size(49, 15);
            label1.TabIndex = 10;
            label1.Text = "Value A:";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(278, 401);
            Controls.Add(btnDivide);
            Controls.Add(btnMultiply);
            Controls.Add(btnSubtract);
            Controls.Add(btnAdd);
            Controls.Add(txtResult);
            Controls.Add(txtB);
            Controls.Add(txtA);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Nicer Calculator";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnDivide;
        private Button btnMultiply;
        private Button btnSubtract;
        private Button btnAdd;
        private TextBox txtResult;
        private TextBox txtB;
        private TextBox txtA;
        private Label label3;
        private Label label2;
        private Label label1;
    }
}
