namespace CalculatorNicer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            txtResult.Text = Calc.Add(txtA.Text, txtB.Text);
        }

        private void btnSubtract_Click(object sender, EventArgs e)
        {
            txtResult.Text = Calc.Subtract(txtA.Text, txtB.Text);
        }

        private void btnMultiply_Click(object sender, EventArgs e)
        {
            txtResult.Text = Calc.Multiply(txtA.Text, txtB.Text);

        }

        private void btnDivide_Click(object sender, EventArgs e)
        {
            txtResult.Text = Calc.Divide(txtA.Text, txtB.Text);

        }
    }
}
