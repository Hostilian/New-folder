namespace CalculatorUgly
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            txtResult.Text = (Convert.ToDouble(txtA.Text) + double.Parse(txtB.Text)).ToString();
        }

        private void btnSubtract_Click(object sender, EventArgs e)
        {
            txtResult.Text = (Convert.ToDouble(txtA.Text) - double.Parse(txtB.Text)).ToString();
        }

        private void btnMultiply_Click(object sender, EventArgs e)
        {
            txtResult.Text = (Convert.ToDouble(txtA.Text) * double.Parse(txtB.Text)).ToString();
        }

        private void btnDivide_Click(object sender, EventArgs e)
        {
            txtResult.Text = (Convert.ToDouble(txtA.Text) / double.Parse(txtB.Text)).ToString();
        }
    }
}
