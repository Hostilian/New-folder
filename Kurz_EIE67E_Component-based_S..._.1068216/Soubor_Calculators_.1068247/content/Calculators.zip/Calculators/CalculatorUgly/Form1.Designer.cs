﻿namespace CalculatorUgly
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            txtA = new TextBox();
            txtB = new TextBox();
            txtResult = new TextBox();
            btnAdd = new Button();
            btnSubtract = new Button();
            btnMultiply = new Button();
            btnDivide = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(24, 29);
            label1.Name = "label1";
            label1.Size = new Size(49, 15);
            label1.TabIndex = 0;
            label1.Text = "Value A:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(24, 69);
            label2.Name = "label2";
            label2.Size = new Size(48, 15);
            label2.TabIndex = 1;
            label2.Text = "Value B:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(24, 123);
            label3.Name = "label3";
            label3.Size = new Size(42, 15);
            label3.TabIndex = 2;
            label3.Text = "Result:";
            // 
            // txtA
            // 
            txtA.Location = new Point(121, 26);
            txtA.Name = "txtA";
            txtA.Size = new Size(135, 23);
            txtA.TabIndex = 3;
            // 
            // txtB
            // 
            txtB.Location = new Point(121, 66);
            txtB.Name = "txtB";
            txtB.Size = new Size(135, 23);
            txtB.TabIndex = 4;
            // 
            // txtResult
            // 
            txtResult.Location = new Point(121, 120);
            txtResult.Name = "txtResult";
            txtResult.Size = new Size(135, 23);
            txtResult.TabIndex = 5;
            // 
            // btnAdd
            // 
            btnAdd.Font = new Font("Segoe UI", 36F, FontStyle.Bold);
            btnAdd.Location = new Point(24, 174);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(113, 107);
            btnAdd.TabIndex = 6;
            btnAdd.Text = "+";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnSubtract
            // 
            btnSubtract.Font = new Font("Segoe UI", 36F, FontStyle.Bold);
            btnSubtract.Location = new Point(143, 174);
            btnSubtract.Name = "btnSubtract";
            btnSubtract.Size = new Size(113, 107);
            btnSubtract.TabIndex = 7;
            btnSubtract.Text = "-";
            btnSubtract.UseVisualStyleBackColor = true;
            btnSubtract.Click += btnSubtract_Click;
            // 
            // btnMultiply
            // 
            btnMultiply.Font = new Font("Segoe UI", 36F, FontStyle.Bold);
            btnMultiply.Location = new Point(24, 287);
            btnMultiply.Name = "btnMultiply";
            btnMultiply.Size = new Size(113, 107);
            btnMultiply.TabIndex = 8;
            btnMultiply.Text = "*";
            btnMultiply.UseVisualStyleBackColor = true;
            btnMultiply.Click += btnMultiply_Click;
            // 
            // btnDivide
            // 
            btnDivide.Font = new Font("Segoe UI", 36F, FontStyle.Bold);
            btnDivide.Location = new Point(143, 287);
            btnDivide.Name = "btnDivide";
            btnDivide.Size = new Size(113, 107);
            btnDivide.TabIndex = 9;
            btnDivide.Text = "/";
            btnDivide.UseVisualStyleBackColor = true;
            btnDivide.Click += btnDivide_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(280, 417);
            Controls.Add(btnDivide);
            Controls.Add(btnMultiply);
            Controls.Add(btnSubtract);
            Controls.Add(btnAdd);
            Controls.Add(txtResult);
            Controls.Add(txtB);
            Controls.Add(txtA);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Ugly Calculator";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox txtA;
        private TextBox txtB;
        private TextBox txtResult;
        private Button btnAdd;
        private Button btnSubtract;
        private Button btnMultiply;
        private Button btnDivide;
    }
}
