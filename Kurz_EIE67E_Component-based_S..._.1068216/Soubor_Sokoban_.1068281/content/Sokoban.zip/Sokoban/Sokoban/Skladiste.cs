﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sokoban
{
    public enum Misto { Volne, Bedna, Zed, Blok };
    public enum Smer { Vlevo, Vpravo, Nahoru, Dolu };

    public struct Poloha
    {
        public int x;
        public int y;
        public Poloha(int xp, int yp)
        {
            x = xp;
            y = yp;
        }
    }

    public static class Skladiste
    {
        public static int[,] sklad = new int[14, 14];
        public static Poloha skladnik = new Poloha();
        public static List<Poloha> cile = new List<Poloha>();

        // . = nic, X = stěna, 2 = bedna, 3 = skladník, 4 = cíl, 6 = cíl s bednou
        public static void NactiSklad() {

            sklad = new int[14, 14];

            string radek;
            int y = 0;
            cile.Clear();
            
            System.IO.StreamReader soubor = new System.IO.StreamReader("level2.txt");
            while ((radek = soubor.ReadLine()) != null)
            {
                for (int x = 0; x < 14; x++)
                {
                    char c = radek[x];
                    switch (c) {
                        case '.': sklad[x, y] = 0; break;
                        case 'X': sklad[x, y] = 1; break;
                        case '2': sklad[x, y] = 2; break;
                        case '3': skladnik.x = x; skladnik.y = y; break;
                        case '4': cile.Add(new Poloha(x,y)); break;
                        case '6': cile.Add(new Poloha(x, y)); sklad[x, y] = 2; break;
                    }
                    
                }
                y++;
            }

            soubor.Close();
        }

        public static bool JeCil(Poloha p)
        {
            return cile.Contains(p);
        }

        public static bool BednaVCili(Poloha p)
        {
            if (ObsahMista(p) == Misto.Bedna && JeCil(p)) return true;
            return false;
        }

        public static bool BednaVCili(int x, int y)
        {
            Poloha p = new Poloha(x, y);
            return BednaVCili(p);
        }


        public static bool JeKonec()
        {
            bool vysledek = true;

            foreach (Poloha p in cile)
            {
                vysledek = (vysledek && BednaVCili(p));
            }

            return vysledek;
        }

        public static Misto ObsahMista(Poloha p)
        {
            switch (sklad[p.x,p.y]) {
                case 1: return Misto.Zed;
                case 2: return Misto.Bedna;
                default: return Misto.Volne;
            }
        }

        public static bool LzePosunout(Smer s, Poloha p)
        {
            Poloha dalsiMisto = p;

            switch (s)
            {
                case Smer.Vlevo:
                    dalsiMisto = new Poloha(p.x - 1, p.y);
                    break;
                case Smer.Vpravo: 
                    dalsiMisto = new Poloha(p.x + 1, p.y);
                    break;
                case Smer.Nahoru: 
                    dalsiMisto = new Poloha(p.x, p.y - 1);
                    break;
                case Smer.Dolu: 
                    dalsiMisto = new Poloha(p.x, p.y + 1);
                    break;
            }
            return (ObsahMista(dalsiMisto) == Misto.Volne);
        }

        public static void PosunBednu(Smer s, Poloha p)
        {
            switch (s)
            {
                case Smer.Vlevo:
                    sklad[p.x - 1, p.y] = 2;
                    sklad[p.x, p.y] = 0;
                    break;
                case Smer.Vpravo:
                    sklad[p.x + 1, p.y] = 2;
                    sklad[p.x, p.y] = 0;
                    break;
                case Smer.Nahoru:
                    sklad[p.x, p.y - 1] = 2;
                    sklad[p.x, p.y] = 0;
                    break;
                case Smer.Dolu:
                    sklad[p.x, p.y + 1] = 2;
                    sklad[p.x, p.y] = 0;
                    break;
            }
        }

        public static bool Posun(Smer smer)
        {
            Poloha posunKam = skladnik;

            switch (smer)
            {
                case Smer.Vlevo: posunKam = new Poloha(skladnik.x-1,skladnik.y);  break;
                case Smer.Vpravo: posunKam = new Poloha(skladnik.x + 1, skladnik.y); break;
                case Smer.Nahoru: posunKam = new Poloha(skladnik.x, skladnik.y - 1); break;
                case Smer.Dolu: posunKam = new Poloha(skladnik.x, skladnik.y + 1); break;
            }

            switch (ObsahMista(posunKam))
            {
                case Misto.Volne: 
                    skladnik = posunKam; 
                    break;
                case Misto.Bedna: 
                    if (LzePosunout(smer, posunKam))
                    {
                        PosunBednu(smer, posunKam);
                        skladnik = posunKam;
                    }
                    break;
                case Misto.Zed: 
                    break;
            } 

            return JeKonec();
        }
    }
}
