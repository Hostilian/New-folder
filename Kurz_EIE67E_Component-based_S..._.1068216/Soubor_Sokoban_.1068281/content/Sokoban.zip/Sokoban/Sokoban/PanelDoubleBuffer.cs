﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Sokoban
{
    // Tato trida je rozsirenim puvodniho kontejneru Panel. V nasi aplikace je vyuzita jako prvek, na jehoz
    // platne se cela hra odehrava. Protoze ale kvuli plynulemu vykreslovani potrebujeme vyuzit double buffering,
    // musime vytvorit podtridu Panelu, jejimz jedinym rozdilem oproti puvodni tride je to, ze v jejim konstruktoru
    // je aktivovan double buffering pro vykreslovani na jejim objektu Graphics. Tato odvozena trida se pak automaticky
    // zobrazi v Toolboxu a lze ji vlozit na formular stejne jako puvodni Panel.

    public class PanelDoubleBuffer : Panel
    {
        public PanelDoubleBuffer()
            : base()
        {
            this.SetStyle(ControlStyles.DoubleBuffer, true);
            this.SetStyle(ControlStyles.AllPaintingInWmPaint, true);
            this.SetStyle(ControlStyles.UserPaint, true);
        }
    }
}
