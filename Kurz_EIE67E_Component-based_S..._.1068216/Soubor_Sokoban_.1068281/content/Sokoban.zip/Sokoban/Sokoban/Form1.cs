﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sokoban
{
    public partial class Form1 : Form
    {
        Image zed = global::Sokoban.Properties.Resources.zed;
        Image smajlik = global::Sokoban.Properties.Resources.smajlik;
        Image bedna = global::Sokoban.Properties.Resources.bedna;
        Image bednaCil = global::Sokoban.Properties.Resources.bedna_cil;
        Image cil = global::Sokoban.Properties.Resources.cil;
        
        public Form1()
        {
            Skladiste.NactiSklad();
            InitializeComponent();
        }

        private void panelDoubleBuffer1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;

            foreach (Poloha p in Skladiste.cile)
            {
                g.DrawImage(cil, p.x * 30, p.y * 30);
            }

            g.DrawImage(smajlik, Skladiste.skladnik.x * 30, Skladiste.skladnik.y * 30);

            for (int x = 0; x < 14; x++)
            {
                for (int y = 0; y < 14; y++)
                {
                    switch (Skladiste.sklad[x, y])
                    {
                        case 1: g.DrawImage(zed, x * 30, y * 30); break;
                        case 2: 
                            if (Skladiste.BednaVCili(x,y)) g.DrawImage(bednaCil, x * 30, y * 30); 
                               else g.DrawImage(bedna, x*30, y*30); 
                            break;
                    }
                }
            }
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            Keys tlacitko = e.KeyData;

            bool vysledek = ZpracujPohyb(tlacitko);
            panelDoubleBuffer1.Invalidate();

            if (vysledek)
            {
                MessageBox.Show("Výhra!");
                Skladiste.NactiSklad();
                panelDoubleBuffer1.Invalidate();
            }
        }

        private static bool ZpracujPohyb(Keys tlacitko)
        {
            bool vysledek = false;

            switch (tlacitko)
            {
                case Keys.Up:
                    vysledek = Skladiste.Posun(Smer.Nahoru);
                    break;
                case Keys.Down:
                    vysledek = Skladiste.Posun(Smer.Dolu);
                    break;
                case Keys.Left:
                    vysledek = Skladiste.Posun(Smer.Vlevo);
                    break;
                case Keys.Right:
                    vysledek = Skladiste.Posun(Smer.Vpravo);
                    break;
            }
            // na zaver vratime vysledek pohybu
            return vysledek;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Skladiste.NactiSklad();
            panelDoubleBuffer1.Invalidate();
        }

        private void button1_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Up:
                case Keys.Down:
                case Keys.Left:
                case Keys.Right:
                    e.IsInputKey = true;
                    break;
            }
        }



    }
}
