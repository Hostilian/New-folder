﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnPlus_Click(object sender, EventArgs e)
        {
            try
            {
                txtResult.Text = (Convert.ToInt32(txtValueA.Text) + Convert.ToInt32(txtValueB.Text)).ToString();
            }
            catch (Exception)
            {
                MessageBox.Show("Check your numbers!");
            }
        }

        private void btnMinus_Click(object sender, EventArgs e)
        {
            try
            {
                txtResult.Text = (Convert.ToInt32(txtValueA.Text) - Convert.ToInt32(txtValueB.Text)).ToString();
            }
            catch (Exception)
            {
                MessageBox.Show("Check your numbers!");
            }
        }

        private void btnMultiply_Click(object sender, EventArgs e)
        {
            try
            {
                txtResult.Text = (Convert.ToInt32(txtValueA.Text) * Convert.ToInt32(txtValueB.Text)).ToString();
            }
            catch (Exception)
            {
                MessageBox.Show("Check your numbers!");
            }
        }

        private void btnDivide_Click(object sender, EventArgs e)
        {
            try
            {
                txtResult.Text = (Convert.ToInt32(txtValueA.Text) / Convert.ToInt32(txtValueB.Text)).ToString();
            }
            catch (Exception)
            {
                MessageBox.Show("Check your numbers!");
            }
        }
    }
}
