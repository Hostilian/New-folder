﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BetterCalculator
{
    public static class Calc
    {
        public static int Add(int a, int b)
        {
            return a + b;
        }

        public static string Add(string a, string b)
        {
            try
            {
                return Add(Convert.ToInt32(a), Convert.ToInt32(b)).ToString();
            }
            catch (FormatException ex)
            {
                throw new MathOperationException("Error during conversion to number", ex);
            }
        }

        public static int Subtract(int a, int b)
        {
            return a - b;
        }

        public static string Subtract(string a, string b)
        {
            try
            {
                return Subtract(Convert.ToInt32(a), Convert.ToInt32(b)).ToString();

            }
            catch (FormatException ex)
            {

                throw new MathOperationException("Error during conversion to number", ex);
            }
        }

        public static int Multiply(int a, int b)
        {
            return a * b;
        }
        public static string Multiply(string a, string b)
        {
            try
            {
                return Multiply(Convert.ToInt32(a), Convert.ToInt32(b)).ToString();
            }
            catch (FormatException ex)
            {
                throw new MathOperationException("Error during conversion to number", ex);
            }
        }
        public static int Divide(int a, int b)
        {
            try
            {
                return a / b;
            }
            catch (DivideByZeroException ex)
            {
                throw new MathOperationException("Division by zero!", ex);
            }
        }
        public static string Divide(string a, string b)
        {
            try
            {
                return Divide(Convert.ToInt32(a), Convert.ToInt32(b)).ToString();

            }
            catch (FormatException ex)
            {
                throw new MathOperationException("Error during conversion to number", ex);
            }
        }
    }
}
