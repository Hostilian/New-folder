﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BetterCalculator
{
    public class MathOperationException : Exception
    {
        public MathOperationException() { }
        public MathOperationException(string message) : base(message) { }
        public MathOperationException(string message, Exception inner) : base(message, inner) { }
    }
}
