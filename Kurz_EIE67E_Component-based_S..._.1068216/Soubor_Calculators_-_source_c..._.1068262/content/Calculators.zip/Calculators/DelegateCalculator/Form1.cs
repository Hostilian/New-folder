﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BetterCalculator;

namespace DelegateCalculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            DelegateCalc.ShowOutput += new Output(ShowResult);
            DelegateCalc.ShowOutput += new Output(ShowHidden);
        }

        public void ShowResult(string s)
        {
            txtResult.Text = s;
        }

        public void ShowHidden(string s)
        {
            label4.Text = s;
        }

        private void btnPlus_Click(object sender, EventArgs e)
        {
            DelegateCalc.Add(txtValueA.Text, txtValueB.Text);
        }

        private void btnMinus_Click(object sender, EventArgs e)
        {
            DelegateCalc.Subtract(txtValueA.Text, txtValueB.Text);
        }

        private void btnMultiply_Click(object sender, EventArgs e)
        {
            DelegateCalc.Multiply(txtValueA.Text, txtValueB.Text);
        }

        private void btnDivide_Click(object sender, EventArgs e)
        {
            DelegateCalc.Divide(txtValueA.Text, txtValueB.Text);
        }
    }
}
