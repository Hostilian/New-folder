﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BetterCalculator;

namespace DelegateCalculator
{
    public delegate void Output(string s);

    public static class DelegateCalc
    {
        public static Output ShowOutput { get; set; }
        public static void Add(int a, int b)
        {
            ShowOutput?.Invoke(Calc.Add(a, b).ToString());
        }

        public static void Add(string a, string b)
        {
            ShowOutput?.Invoke(Calc.Add(a, b));
        }

        public static void Subtract(int a, int b)
        {
            ShowOutput?.Invoke(Calc.Subtract(a, b).ToString());
        }

        public static void Subtract(string a, string b)
        {
            ShowOutput?.Invoke(Calc.Subtract(a, b));
        }

        public static void Multiply(int a, int b)
        {
            ShowOutput?.Invoke(Calc.Multiply(a, b).ToString());
        }

        public static void Multiply(string a, string b)
        {
            ShowOutput?.Invoke(Calc.Multiply(a, b));
        }

        public static void Divide(int a, int b)
        {
            ShowOutput?.Invoke(Calc.Divide(a, b).ToString());
        }

        public static void Divide(string a, string b)
        {
            ShowOutput?.Invoke(Calc.Divide(a, b));
        }


    }
}
