using Microsoft.VisualBasic.Logging;

namespace Rentals
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            dgvStock.AutoGenerateColumns = false;
            dgvRented.AutoGenerateColumns = false;
            dgvCustomers.DataSource = Database.Customers;
            dgvStock.DataSource = Database.Stock;
        }

        private void SetButtons()
        {
            btnRent.Enabled = dgvStock.Rows.Count > 0;
            btnReturn.Enabled = dgvRented.Rows.Count > 0;
        }

        private void btnRent_Click(object sender, EventArgs e)
        {
            if (!Database.Rent(dgvCustomers.CurrentRow.DataBoundItem,
                              dgvStock.CurrentRow.DataBoundItem))
                MessageBox.Show("The customer must be adult to rent this item!");

            SetButtons();
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            Database.Return(dgvCustomers.CurrentRow.DataBoundItem, dgvRented.CurrentRow.DataBoundItem);

            SetButtons();
        }

        private void dgvCustomers_SelectionChanged(object sender, EventArgs e)
        {
            dgvRented.DataSource = ((Customer)dgvCustomers.CurrentRow.DataBoundItem).Rented;

            SetButtons();
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Database.Serialize();
        }
    }
}
