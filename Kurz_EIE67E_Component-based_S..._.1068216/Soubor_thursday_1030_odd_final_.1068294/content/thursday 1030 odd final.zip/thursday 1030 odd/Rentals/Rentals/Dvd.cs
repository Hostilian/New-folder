﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rentals
{
    [Serializable()]
    public class Dvd : Disc
    {
        public string Director { get; set; }
        public bool Restricted { get; set; }

        public override string FullTitle => $"{Title} - director: {Director}";
        public override string Type => "DVD";

        public Dvd() { }

        public Dvd(string title, string director, string genre, int price, bool restricted = false) 
            : base(title, genre, price)
        {
            Director = director;
            Restricted = restricted;
        }

    }
}
