﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Rentals
{
    [Serializable()]
    [XmlInclude(typeof(CD)), XmlInclude(typeof(Dvd))]
    public abstract class Disc
    {
        public string Title { get; set; }
        public string Genre { get; set; }
        public int Price { get; set; }

        public abstract string FullTitle { get; }
        public abstract string Type { get; }

        public Disc() { }

        public Disc(string title, string genre, int price)
        {
            Title = title;
            Genre = genre;
            Price = price;
        }
    }
}
