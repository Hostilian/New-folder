﻿namespace Rentals
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            btnRent = new Button();
            btnReturn = new Button();
            dgvCustomers = new DataGridView();
            dgvStock = new DataGridView();
            Column1 = new DataGridViewTextBoxColumn();
            Column2 = new DataGridViewTextBoxColumn();
            Column3 = new DataGridViewTextBoxColumn();
            Column4 = new DataGridViewTextBoxColumn();
            dgvRented = new DataGridView();
            Column5 = new DataGridViewTextBoxColumn();
            Column6 = new DataGridViewTextBoxColumn();
            Column7 = new DataGridViewTextBoxColumn();
            Column8 = new DataGridViewTextBoxColumn();
            Column9 = new DataGridViewTextBoxColumn();
            Column10 = new DataGridViewTextBoxColumn();
            Column11 = new DataGridViewTextBoxColumn();
            Column12 = new DataGridViewTextBoxColumn();
            Column13 = new DataGridViewCheckBoxColumn();
            ((System.ComponentModel.ISupportInitialize)dgvCustomers).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvStock).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvRented).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(10, 11);
            label1.Name = "label1";
            label1.Size = new Size(67, 15);
            label1.TabIndex = 0;
            label1.Text = "Customers:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(568, 8);
            label2.Name = "label2";
            label2.Size = new Size(39, 15);
            label2.TabIndex = 1;
            label2.Text = "Stock:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 254);
            label3.Name = "label3";
            label3.Size = new Size(212, 15);
            label3.TabIndex = 2;
            label3.Text = "Rented items of the selected customer:";
            // 
            // btnRent
            // 
            btnRent.Location = new Point(438, 29);
            btnRent.Name = "btnRent";
            btnRent.Size = new Size(125, 43);
            btnRent.TabIndex = 3;
            btnRent.Text = "Rent";
            btnRent.UseVisualStyleBackColor = true;
            btnRent.Click += btnRent_Click;
            // 
            // btnReturn
            // 
            btnReturn.Location = new Point(438, 78);
            btnReturn.Name = "btnReturn";
            btnReturn.Size = new Size(125, 43);
            btnReturn.TabIndex = 4;
            btnReturn.Text = "Return";
            btnReturn.UseVisualStyleBackColor = true;
            btnReturn.Click += btnReturn_Click;
            // 
            // dgvCustomers
            // 
            dgvCustomers.AllowUserToAddRows = false;
            dgvCustomers.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvCustomers.Columns.AddRange(new DataGridViewColumn[] { Column9, Column10, Column11, Column12, Column13 });
            dgvCustomers.EditMode = DataGridViewEditMode.EditProgrammatically;
            dgvCustomers.Location = new Point(12, 29);
            dgvCustomers.MultiSelect = false;
            dgvCustomers.Name = "dgvCustomers";
            dgvCustomers.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvCustomers.Size = new Size(419, 213);
            dgvCustomers.TabIndex = 5;
            dgvCustomers.SelectionChanged += dgvCustomers_SelectionChanged;
            // 
            // dgvStock
            // 
            dgvStock.AllowUserToAddRows = false;
            dgvStock.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvStock.Columns.AddRange(new DataGridViewColumn[] { Column1, Column2, Column3, Column4 });
            dgvStock.EditMode = DataGridViewEditMode.EditProgrammatically;
            dgvStock.Location = new Point(569, 29);
            dgvStock.MultiSelect = false;
            dgvStock.Name = "dgvStock";
            dgvStock.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvStock.Size = new Size(396, 218);
            dgvStock.TabIndex = 6;
            // 
            // Column1
            // 
            Column1.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            Column1.DataPropertyName = "FullTitle";
            Column1.HeaderText = "Full title";
            Column1.Name = "Column1";
            Column1.Width = 74;
            // 
            // Column2
            // 
            Column2.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            Column2.DataPropertyName = "Type";
            Column2.HeaderText = "Type";
            Column2.Name = "Column2";
            Column2.Width = 56;
            // 
            // Column3
            // 
            Column3.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            Column3.DataPropertyName = "Genre";
            Column3.HeaderText = "Genre";
            Column3.Name = "Column3";
            Column3.Width = 63;
            // 
            // Column4
            // 
            Column4.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            Column4.DataPropertyName = "Price";
            Column4.HeaderText = "Price";
            Column4.Name = "Column4";
            Column4.Width = 58;
            // 
            // dgvRented
            // 
            dgvRented.AllowUserToAddRows = false;
            dgvRented.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvRented.Columns.AddRange(new DataGridViewColumn[] { Column5, Column6, Column7, Column8 });
            dgvRented.EditMode = DataGridViewEditMode.EditProgrammatically;
            dgvRented.Location = new Point(13, 271);
            dgvRented.MultiSelect = false;
            dgvRented.Name = "dgvRented";
            dgvRented.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvRented.Size = new Size(560, 198);
            dgvRented.TabIndex = 7;
            // 
            // Column5
            // 
            Column5.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            Column5.DataPropertyName = "FullTitle";
            Column5.HeaderText = "Full Title";
            Column5.Name = "Column5";
            Column5.Width = 76;
            // 
            // Column6
            // 
            Column6.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            Column6.DataPropertyName = "Type";
            Column6.HeaderText = "Type";
            Column6.Name = "Column6";
            Column6.Width = 56;
            // 
            // Column7
            // 
            Column7.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            Column7.DataPropertyName = "Genre";
            Column7.HeaderText = "Genre";
            Column7.Name = "Column7";
            Column7.Width = 63;
            // 
            // Column8
            // 
            Column8.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            Column8.DataPropertyName = "Price";
            Column8.HeaderText = "Price";
            Column8.Name = "Column8";
            Column8.Width = 58;
            // 
            // Column9
            // 
            Column9.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            Column9.DataPropertyName = "FirstName";
            Column9.HeaderText = "First Name";
            Column9.Name = "Column9";
            Column9.Width = 89;
            // 
            // Column10
            // 
            Column10.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            Column10.DataPropertyName = "LastName";
            Column10.HeaderText = "Last Name";
            Column10.Name = "Column10";
            Column10.Width = 88;
            // 
            // Column11
            // 
            Column11.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            Column11.DataPropertyName = "Address";
            Column11.HeaderText = "Address";
            Column11.Name = "Column11";
            Column11.Width = 74;
            // 
            // Column12
            // 
            Column12.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            Column12.DataPropertyName = "BirthYear";
            Column12.HeaderText = "Year of birth";
            Column12.Name = "Column12";
            Column12.Width = 96;
            // 
            // Column13
            // 
            Column13.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            Column13.DataPropertyName = "Adult";
            Column13.HeaderText = "Adult";
            Column13.Name = "Column13";
            Column13.Resizable = DataGridViewTriState.True;
            Column13.SortMode = DataGridViewColumnSortMode.Automatic;
            Column13.Width = 61;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(977, 486);
            Controls.Add(dgvRented);
            Controls.Add(dgvStock);
            Controls.Add(dgvCustomers);
            Controls.Add(btnReturn);
            Controls.Add(btnRent);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            FormClosed += Form1_FormClosed;
            ((System.ComponentModel.ISupportInitialize)dgvCustomers).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvStock).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvRented).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Button btnRent;
        private Button btnReturn;
        private DataGridView dgvCustomers;
        private DataGridView dgvStock;
        private DataGridView dgvRented;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column3;
        private DataGridViewTextBoxColumn Column4;
        private DataGridViewTextBoxColumn Column5;
        private DataGridViewTextBoxColumn Column6;
        private DataGridViewTextBoxColumn Column7;
        private DataGridViewTextBoxColumn Column8;
        private DataGridViewTextBoxColumn Column9;
        private DataGridViewTextBoxColumn Column10;
        private DataGridViewTextBoxColumn Column11;
        private DataGridViewTextBoxColumn Column12;
        private DataGridViewCheckBoxColumn Column13;
    }
}
