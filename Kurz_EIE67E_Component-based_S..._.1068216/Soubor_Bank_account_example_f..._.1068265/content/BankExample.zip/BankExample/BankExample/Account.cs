﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankExample
{
    public class Account
    {
        public Client Client { get; set; }
        public decimal Balance { get; private set; }
        public decimal Overdraft { get; private set; }

        public decimal AvailableTotal => Balance + Overdraft;

        public Account(Client client) 
            => Client = client;

        public Account(Client client, decimal balance) : this(client) 
            => Balance = balance;

        public Account(Client client, decimal balance, decimal overdraft) : this(client, balance) 
            => Overdraft = overdraft;

        public override string ToString()
        {
            return $"{Client} has balance of {Balance} and available total of {AvailableTotal}";
        }

        public void Deposit(decimal amount)
        {
            if (amount <= 0) 
                throw new NonPositiveAmountException("The amount must be greater than zero!");
            Balance += amount;
        }

        public void Withdraw(decimal amount)
        {
            if (amount <= 0)
                throw new NonPositiveAmountException("The amount must be greater than zero!");
            if (amount > AvailableTotal)
                throw new BalanceException("You cannot withdraw more than you have!");
            Balance -= amount;
        }
    }
}
