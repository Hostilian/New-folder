﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankExample
{
    public class NonPositiveAmountException : BankingOperationException
    {
        public NonPositiveAmountException()
        {
        }

        public NonPositiveAmountException(string? message) : base(message)
        {
        }

        public NonPositiveAmountException(string? message, Exception? innerException) : base(message, innerException)
        {
        }
    }
}
