﻿using BankExample;

var c = new Client("John", "Doe", "Prague");

Console.WriteLine(c);

var a1 = new Account(c);
var a2 = new Account(c, 10000);
var a3 = new Account(c, 20000, 5000);
Console.WriteLine(a1);

try
{
    a1.Withdraw(-1500);
}
catch (NonPositiveAmountException e)
{
    Console.WriteLine("NPAE = " + e.Message);
}
catch (BankingOperationException e) 
{ 
    Console.WriteLine("BOE = " + e.Message); 
}

Console.WriteLine(a1);
//Console.WriteLine(a3);
