﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankExample
{
    public class BankingOperationException : Exception
    {
        public BankingOperationException()
        {
        }

        public BankingOperationException(string? message) : base(message)
        {
        }

        public BankingOperationException(string? message, Exception? innerException) : base(message, innerException)
        {
        }
    }
}
