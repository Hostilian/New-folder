﻿namespace Rentals
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            btnRent = new Button();
            btnReturn = new Button();
            dgvCustomers = new DataGridView();
            dgvStock = new DataGridView();
            dgvRented = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dgvCustomers).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvStock).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvRented).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 9);
            label1.Name = "label1";
            label1.Size = new Size(67, 15);
            label1.TabIndex = 0;
            label1.Text = "Customers:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(547, 9);
            label2.Name = "label2";
            label2.Size = new Size(39, 15);
            label2.TabIndex = 1;
            label2.Text = "Stock:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 263);
            label3.Name = "label3";
            label3.Size = new Size(211, 15);
            label3.TabIndex = 2;
            label3.Text = "Items rented by the selected customer:";
            // 
            // btnRent
            // 
            btnRent.Location = new Point(447, 27);
            btnRent.Name = "btnRent";
            btnRent.Size = new Size(94, 41);
            btnRent.TabIndex = 3;
            btnRent.Text = "Rent";
            btnRent.UseVisualStyleBackColor = true;
            btnRent.Click += btnRent_Click;
            // 
            // btnReturn
            // 
            btnReturn.Location = new Point(447, 75);
            btnReturn.Name = "btnReturn";
            btnReturn.Size = new Size(94, 41);
            btnReturn.TabIndex = 4;
            btnReturn.Text = "Return";
            btnReturn.UseVisualStyleBackColor = true;
            btnReturn.Click += btnReturn_Click;
            // 
            // dgvCustomers
            // 
            dgvCustomers.AllowUserToAddRows = false;
            dgvCustomers.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvCustomers.EditMode = DataGridViewEditMode.EditProgrammatically;
            dgvCustomers.Location = new Point(12, 27);
            dgvCustomers.MultiSelect = false;
            dgvCustomers.Name = "dgvCustomers";
            dgvCustomers.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvCustomers.Size = new Size(429, 223);
            dgvCustomers.TabIndex = 5;
            dgvCustomers.SelectionChanged += dgvCustomers_SelectionChanged;
            // 
            // dgvStock
            // 
            dgvStock.AllowUserToAddRows = false;
            dgvStock.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvStock.EditMode = DataGridViewEditMode.EditProgrammatically;
            dgvStock.Location = new Point(547, 27);
            dgvStock.MultiSelect = false;
            dgvStock.Name = "dgvStock";
            dgvStock.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvStock.Size = new Size(413, 223);
            dgvStock.TabIndex = 6;
            // 
            // dgvRented
            // 
            dgvRented.AllowUserToAddRows = false;
            dgvRented.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvRented.EditMode = DataGridViewEditMode.EditProgrammatically;
            dgvRented.Location = new Point(12, 281);
            dgvRented.MultiSelect = false;
            dgvRented.Name = "dgvRented";
            dgvRented.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvRented.Size = new Size(538, 195);
            dgvRented.TabIndex = 7;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(972, 488);
            Controls.Add(dgvRented);
            Controls.Add(dgvStock);
            Controls.Add(dgvCustomers);
            Controls.Add(btnReturn);
            Controls.Add(btnRent);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Rentals";
            FormClosed += Form1_FormClosed;
            ((System.ComponentModel.ISupportInitialize)dgvCustomers).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvStock).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvRented).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Button btnRent;
        private Button btnReturn;
        private DataGridView dgvCustomers;
        private DataGridView dgvStock;
        private DataGridView dgvRented;
    }
}
