﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace Rentals
{
    [Serializable()]
    public class Customer
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Address { get; set; }
        public int BirthYear { get; set; }

        public BindingList<Disc> Rented { get; private set; } = [];

        public Customer() { }

        public Customer(string firstName, string lastName, string address, int birthYear)
        {
            FirstName = firstName;
            LastName = lastName;
            Address = address;
            BirthYear = birthYear;
        }
    }
}
