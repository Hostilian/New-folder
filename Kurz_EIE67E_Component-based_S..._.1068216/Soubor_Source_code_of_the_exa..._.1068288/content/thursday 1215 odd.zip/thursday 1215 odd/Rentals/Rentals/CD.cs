﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Rentals
{
    [Serializable()]
    public class CD : Disc
    {
        public string Artist { get; set; }

        public CD() { }

        public CD(string title, string artist, string genre, int price) 
            : base(title, genre, price)
        {
            Artist = artist;
        }
    }
}
